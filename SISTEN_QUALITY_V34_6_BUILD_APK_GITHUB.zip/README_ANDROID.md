# SISTEN QUALITY V34.6 — Gerar APK pelo celular

Este pacote foi preparado para gerar o APK usando GitHub Actions, sem Android Studio.

1. Crie um repositório no GitHub.
2. Envie o arquivo `SISTEN_QUALITY_V34_6_Projeto_Android.zip` para a raiz do repositório.
3. Crie `.github/workflows/build-apk.yml` e copie o conteúdo de `build-apk.yml` deste pacote.
4. Abra a aba Actions.
5. Execute `Gerar APK SISTEN QUALITY` > `Run workflow`.
6. Quando terminar, abra a execução concluída e baixe o artefato `SISTEN-QUALITY-V34-6-APK`.
7. Dentro do artefato estará `app-debug.apk`.

O workflow usa um runner hospedado pelo GitHub para instalar Node/Java/Android e executar o Gradle.
